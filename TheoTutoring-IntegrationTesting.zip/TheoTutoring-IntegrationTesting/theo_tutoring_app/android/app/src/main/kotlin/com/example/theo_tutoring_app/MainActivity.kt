package com.example.theo_tutoring_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
